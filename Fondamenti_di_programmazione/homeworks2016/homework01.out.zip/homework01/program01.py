'''Scrivere una funzione mesi(lst) che ritorna una lista di lunghezza uguale a
quella della lista in input lst e che, per ogni i, se nella posizione i della
lista lst vi e' una stringa che codifica una data, allora in quella posizione la
nuova lista ha la stringa  corrispondente al nome del mese indicato nella data,
altrimenti ha il carattere '*'.
Una stringa che codifica una data  e' del tipo gg-mm-aaaa dove gg codifica il
giorno, mm  il mese e aaaa l'anno. Si puo' assumere che non sono presenti date
di anni bisestili.
Vedere il file grade01.txt che contiene gli esempi usati dal grader.

AVVERTENZE: non usare caratteri non ASCII, come le lettere accentate;
non usare moduli che non sono nella libreria standard.
'''


def mesi(lst):
    '''Implementare la funzione qui'''
   
