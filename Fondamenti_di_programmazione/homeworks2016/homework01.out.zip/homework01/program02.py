'''Scrivere una funzione modi(la, lb) che prende in input due liste contenenti
uno stesso numero di stringhe, modifica le liste confrontando le stringhe che
occorrono nella stessa posizione nelle due liste e cancella dalla lista la
maggiore delle due,  se  sono uguali, sono cancellate entrambe.
Vedere il file grade02.txt che contiene gli esempi usati dal grader.



AVVERTENZE: non usare caratteri non ASCII, come le lettere accentate;
non usare moduli che non sono nella libreria standard.
'''


def modi(la,lb):
    '''Implementare la funzione qui'''
        
