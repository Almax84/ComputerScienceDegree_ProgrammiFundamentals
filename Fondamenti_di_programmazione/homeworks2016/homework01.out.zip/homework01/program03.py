'''Scrivere una funzione parole(a,b,txt) che ritorna una lista che all'indice i
ha una stringa contenente tutte le parole presenti  nella linea i della stringa
di input txt di lunghezza  almeno a ed al piu' b.
Per parola si intende una sequenza di caratteri alfabetici (maiuscoli o minuscoli)
di lunghezza massimale. Nella stringa in posisione i della lista di output, le
parole sono separate da un singolo spazio e devono apparire nello stesso
ordine con cui appaiono nella linea i di txt. Se la linea non ha  parole di
lunghezza tra a e b, la stringa corrispondente nella lista di output e' la stringa
vuota.
Il file grade03.txt contiene gli esempi usati dal grader.

AVVERTENZE: non usare caratteri non ASCII, come le lettere accentate;
non usare moduli che non sono nella libreria standard.
'''

def parole(a,b,txt):
    '''Implementare la funzione qui'''
