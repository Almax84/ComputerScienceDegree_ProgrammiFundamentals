'''Definire una classe Punto, una classe Colore ed una classe Rettangolo secondo le seguenti specifiche.

La classe Punto rappresenta un punto. Deve implementare i seguenti metodi:

- Costruttore con argomenti (opzionali) x=0,y=0  che inizializza un punto di coordinate (x,y). Si assume che x e y sono interi non negativi.
- modifica_punto(x1,y1) modifica le coordinate dell'oggetto in (x1,y1)
- to_tuple() ritorna la tupla (x,y) delle coordinate dell'oggetto



La classe Colore deve implementare i seguenti metodi:

- Costruttore con argomenti (opzionali) r=0,g=0,b=0  che inizializza un colore  con la terna RGB (r,g,b). 
- modifica_colore(r1,g1,b1) modifica l'oggetto assegnandogli il  colore RGB (r1,g1,b1)
- miscela(c) restituisce una nuova istanza colore i cui valori sono una miscela dell'istanza corrente  con il colore c. 
  Nella miscela di due colori ogni canale RGB e' definito  da int((c1+c2)/2) dove c1 e c2 sono i valori dello stesso canale 
  RGB dei due colori di partenza.
- to_tuple() ritorna la tupla (r,g,b)  dell'oggetto colore.

La classe Rettangolo deve implementare i seguenti metodi:

- Costruttore con argomenti puntoInizio, larghezza, lunghezza e colore. puntoInizio e' un oggetto della classe Punto 
  e rappresenta il punto in alto a sinistra di un rettangolo di larghezza  parallela all'asse x e altezza parallela all'asse y.
  Di tale rettangolo  vengono dati  la larghezza e l'altezza  mediante i due  interi larghezza e altezza
  e il colore mediante un oggetto della classe Colore. Modificando, tramite i metodi visti sopra, gli oggetti puntoInizio e colore 
  deve modificarsi coerentemente anche l'oggetto rettangolo.


- inter(r) ritorna un' istanza del rettangolo che si ottiene  dall'intersezione dell'istanza attuale con il  rettangolo  r. 
  Il colore del nuovo rettangolo e' la miscela dei colori dei due rettangoli originali.
  Se i due rettangoli non si intersecano viene restituito None.
  Ad esempio dall'intersezione dei due  rettangoli A e B dove:
  A e' il rettangolo con punto di inzio (100,40), larghezza 70, lunghezza 40 e colore (200,200,200) e
  B e' il rettangolo con punto di inzio (120,90), larghezza 40, lunghezza 60 e colore (100,100,100)
  si ottiene il rettangolo con punto di inizio (120,90), larghezza 20, lunghezza 20 e colore (150,150,150)

- super(r) ritorna un'istanza del rettangolo di lunghezza minima e di altezza minima in grado di ricoprire l'area occupata 
  dall'oggetto e dal rettangolo  r. Il colore del nuovo rettangolo e' la miscela dei colori dei due rettangoli originali.

- foto(lista,fname_out) dove lista e' una lista contenente istanze di rettangolo e fname_out e' il nome di un file,  
  crea una immagine in formato PNG e la salva nel file fname_out. L'immagine ha le stesse dimensioni dell'istanza del rettangolo
  che invoca il metodo e fotografa la zona di spazio occupata dal rettangolo dopo che sul piano sono stati sistemati in sequenza 
  i rettangoli che compaiono in lista.

- il metodo speciale __str__ che per il rettangolo produce in una stringa  di testo su quattro righe le informazioni 
  sull'istanza ( vale a dire il punto di inizio, la larghezza, la lunghezza e il colore).
  Ad esempio per il rettangolo con punto di inzio (100,20), larghezza 60, lunghezza 90 e colore (0,250,0) deve restituire:
  'punto di inizio:(100,20)\nlarghezza:60\nlunghezza:90\ncolore(0,255,0)' 

Se necessario, si possono aggiungere altri metodi alle classi.

Per gli esempi vedere il file grade01.txt.

AVVERTENZE: non usare caratteri non ASCII, come le lettere accentate; non importare moduli che non sono nella libreria standard o che non sono forniti
nella cartella dell'homework; non modificare i moduli importati. Se questo file e' piu' grande di 100KB o il grader non termina entro 5 minuti, il punteggio
dell'esercizio e' zero.  
'''

import png


class Punto:
    '''Implementare qui la classe Punto'''
    

class Colore:
    '''Implementare qui la classe Colore'''
        

class Rettangolo:
    '''Implementare qui la classe Rettangolo'''
