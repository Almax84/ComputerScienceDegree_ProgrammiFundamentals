''' Scrivere una funzione burna(fimg, fimg_out, t, *pt) i cui argomenti hanno il
seguente significato:
- fimg: il percorso di un file che contiene un'immagine in formato PNG;
- fimg_out: una stringa contenente il percorso di un file;
- un intero positivo t
- *pt: sequenza variabile di argomenti ognuno dei quali e' una coppia (x, y) che da  le coordinate di un pixel dell'immagine.

La funzione legge l'immagine in fimg ed esegue una visita BFS sul grafo indotto dall'immagine,
in modo simile a quanto visto a lezione.
Le differenze con la BFS vista a lezione sono le seguenti:
1) il punto di partenza non e' un singolo pixel, ma ogni punto in *pt va considerato 
   un punto di partenza (e risulta quindi a distanza zero);
2) occorre considerare anche i pixel diagonali; pertanto  ogni pixel ha potenzialmente 8
   pixel adiacenti anziche' 4;
3) c'e' un arco tra ogni coppia di pixel adiacenti, indipendentemente dalla distanza dei loro colori.
   Il risultato di tale BFS va usato per creare una seconda immagine (da salvare in fimg_out)
   che è uguale all'immagine fimg, tranne che per le seguenti caratteristiche:
   3a) tutti i pixel che risultano a distanza inferiore a t (compresi quelli in *pt) dovranno 
      essere colorati con il colore dato dalla funzione bcolor(c, d), dove c e' il colore originale 
      del pixel e d la sua distanza calcolata dalla BFS; la funzione bcolor ritorna un colore 
      in cui ogni canale RGB è diminuito del doppio di d (se il valore risultante è negativo, 
      se ne prende il valore assoluto);
   3b) i pixel  a distanza t, t+1 e t+2 sono colorati con il  colore rosso (vale a dire (255,0,0)). 
   Pertanto, tutti i pixel che non rientrano nei 2 casi di cui sopra conservano il colore originario. 


Alcuni esempi:
- L'immagine 'img03_01_check.png' deve essere uguale a quella che la funzione 
  salva nel file 'img03_01_out.png' con la chiamata
  burna('img03_01_in.png', 'img03_01_out.png', 100, (250,200))
- L'immagine 'img03_02_check.png' deve essere uguale a quella che la funzione
  salva nel file 'img03_02_out.png' con la chiamata
  burna('img03_01_in.png', 'img03_02_out.png', 100, (150,200), (350,200))

AVVERTENZE: non usare caratteri non ASCII, come le lettere accentate; non
importare moduli che non sono nella libreria standard o che non sono forniti
nella cartella dell'homework; non modificare i moduli importati. Se questo file
e' piu' grande di 100KB o il grader non termina entro 5 minuti, il punteggio
dell'esercizio e' zero.
'''

import png


def burna(fimg, fimg_out, t, *pt):
    '''implementare qui la funzione'''



    
